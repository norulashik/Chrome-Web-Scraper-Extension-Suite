chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'downloadCSV') {
    const blob = new Blob([msg.data], { type: 'text/csv' });

    const reader = new FileReader();
    reader.onload = function () {
      const dataUrl = reader.result;
      chrome.downloads.download({
        url: dataUrl,
        filename: 'scraped_site_data.csv',
        saveAs: true
      });
    };
    reader.readAsDataURL(blob);
  }
});
