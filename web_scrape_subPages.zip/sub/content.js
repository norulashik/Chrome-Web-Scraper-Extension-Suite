(() => {
  const currentURL = window.location.href;
  const origin = location.origin;

  const anchors = Array.from(document.querySelectorAll('a[href]'));
  const links = new Set();

  for (let a of anchors) {
    let href = a.href;
    if (href.startsWith(origin) && !href.includes('#') && !href.includes('mailto:')) {
      links.add(href.split('?')[0]);
    }
  }

  if (document.referrer === "" || currentURL === origin || currentURL === origin + "/") {
    chrome.runtime.sendMessage({ type: "foundLinks", links: Array.from(links) });
  }

  const results = new Set();
  const elements = document.querySelectorAll('p, div, article, section');

  elements.forEach(el => {
    const text = el.innerText.trim();
    if (text && text.length > 40) {
      results.add(text.substring(0, 200));
    }
  });

  chrome.runtime.sendMessage({
    type: "scrapedData",
    data: results.size ? Array.from(results) : ["No content found"]
  });
})();
