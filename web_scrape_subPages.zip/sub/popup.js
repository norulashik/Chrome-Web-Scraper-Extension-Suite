// Final version of popup.js that sequentially scrapes a site and all sub-pages
// One tab at a time, accumulates data and triggers CSV download via background

document.getElementById('scrapeBtn').addEventListener('click', async () => {
  const baseUrl = document.getElementById('urlList').value.trim();
  if (!baseUrl) return alert("Please enter a website URL.");

  const allData = [];

  // Step 1: Open base page and extract internal links
  const baseTab = await chrome.tabs.create({ url: baseUrl, active: false });
  await delay(12000);

  const subLinks = await new Promise(resolve => {
    const listener = (msg, sender) => {
      if (msg.type === "foundLinks") {
        chrome.runtime.onMessage.removeListener(listener);
        chrome.tabs.remove(baseTab.id);
        resolve(msg.links);
      }
    };
    chrome.runtime.onMessage.addListener(listener);
    chrome.scripting.executeScript({
      target: { tabId: baseTab.id },
      files: ['content.js']
    });
  });

  // Step 2: Scrape base page first
  const baseResult = await scrapePage(baseUrl);
  allData.push(baseResult);

  // Step 3: Scrape each sub-link one-by-one (limit to 3)
  for (let link of subLinks.slice(0, 100)) {
    const subResult = await scrapePage(link);
    allData.push(subResult);
  }

  // Step 4: Trigger CSV download
  if (allData.length > 0) {
    const rows = allData.flatMap(entry =>
      entry.contentArray.map(c => `"${entry.url}","${c.replace(/"/g, '""')}"`)
    );
    const csv = "URL,Content Preview\n" + rows.join('\n');
    chrome.runtime.sendMessage({ type: 'downloadCSV', data: csv });
  } else {
    alert("No content scraped.");
  }
});

async function scrapePage(url) {
  return new Promise(async (resolve) => {
    try {
      const tab = await chrome.tabs.create({ url: url, active: false });
      await delay(12000);

      const result = await new Promise((res) => {
        const timeout = setTimeout(() => {
          chrome.tabs.remove(tab.id);
          res({ url, contentArray: ["Timeout or no response"] });
        }, 25000);

        const listener = (msg, sender) => {
          if (msg.type === 'scrapedData' && sender.tab.id === tab.id) {
            clearTimeout(timeout);
            chrome.runtime.onMessage.removeListener(listener);
            chrome.tabs.remove(tab.id);
            res({ url, contentArray: msg.data });
          }
        };

        chrome.runtime.onMessage.addListener(listener);
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
      });

      resolve(result);
    } catch (err) {
      resolve({ url, contentArray: ["Error opening tab"] });
    }
  });
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
