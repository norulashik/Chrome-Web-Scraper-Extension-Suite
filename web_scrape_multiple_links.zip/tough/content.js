(() => {
  try {
    const results = new Set();
    const blocks = document.querySelectorAll('div, article, section');

    for (let block of blocks) {
      const text = block.innerText.trim();
      if (text.length > 40 && text.split('\n').length >= 2) {
        const preview = text.split('\n').slice(0, 3).join(' | ').substring(0, 200);
        results.add(preview);  // Set automatically avoids duplicates
      }
    }

    chrome.runtime.sendMessage({
      type: "scrapedData",
      data: [...results].length > 0 ? [...results] : ["No suitable content found"]
    });
  } catch (err) {
    chrome.runtime.sendMessage({
      type: "scrapedData",
      data: [`Error: ${err.message}`]
    });
  }
})();
