document.getElementById('scrapeBtn').addEventListener('click', async () => {
  const textarea = document.getElementById('urlList');
  const urls = textarea.value.split('\n').map(u => u.trim()).filter(Boolean);

  if (urls.length === 0) {
    alert("Please enter at least one URL.");
    return;
  }

  const allData = [];

  for (const url of urls) {
    const tab = await chrome.tabs.create({ url, active: false });

    await new Promise(resolve => setTimeout(resolve, 5000));

    const result = await new Promise(resolve => {
      chrome.runtime.onMessage.addListener(function listener(msg, sender) {
        if (msg.type === 'scrapedData') {
          chrome.runtime.onMessage.removeListener(listener);
          chrome.tabs.remove(tab.id);
          resolve({ url, contentArray: msg.data });
        }
      });

      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
    });

    allData.push(result);
  }

  // Combine all data and download as a single CSV
  const rows = allData.flatMap(entry =>
    entry.contentArray.map(c => `"${entry.url}","${c.replace(/"/g, '""')}"`)
  );

  const csv = "URL,Content Preview\n" + rows.join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const urlObj = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = urlObj;
  a.download = `scraped_data.csv`;
  a.click();
  URL.revokeObjectURL(urlObj);
});
