(function () {
  const results = [];
  const blocks = document.querySelectorAll('div, article, section');

  blocks.forEach(block => {
    const text = block.innerText.trim();
    if (text.length > 40 && text.split('\n').length >= 2) {
      results.push({
        content: text.split('\n').slice(0, 3).join(' | ').substring(0, 200)
      });
    }
  });

  if (results.length === 0) {
    alert('No content found to scrape.');
    return;
  }

  const csv = "Content Preview\n" + results.map(r => `"${r.content}"`).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'scraped_data.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
})();
